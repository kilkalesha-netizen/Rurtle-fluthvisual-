package com.fluthvisual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final String[] CATEGORIES = {"Combat", "Visuals", "Player", "World", "World All"};
    private int selectedCategory = 1;

    private static final String[][] MODULES = {
        { },
        { "Custom Sky", "View Model", "Hand Aura", "Block Overlay", "Aspect Ratio", "Watermark" },
        { },
        { "Full Bright" },
        { }
    };

    private final List<String> enabledModules = new ArrayList<>();

    private long openTime = -1;
    private static final long ANIM_DURATION = 250L;
    private static final Identifier AVATAR = Identifier.of("fluthvisual", "avatar.png");

    public ClickGui() {
        super(Text.literal("Fluth Visual"));
    }

    private float getAnimationProgress() {
        if (openTime == -1) openTime = System.currentTimeMillis();
        long elapsed = System.currentTimeMillis() - openTime;
        float t = Math.min(1.0f, elapsed / (float) ANIM_DURATION);
        return 1.0f - (1.0f - t) * (1.0f - t);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float anim = getAnimationProgress();
        if (anim <= 0.01f) return;

        int alpha = (int) (anim * 255);
        int screenW = this.width;
        int screenH = this.height;

        int panelW = 380;
        int panelH = 240;
        int panelX = (screenW - panelW) / 2;
        int panelY = (screenH - panelH) / 2;

        int bg = withAlpha(0x0A0A12, alpha);
        int border = withAlpha(0x8B5CF6, alpha);
        int innerBorder = withAlpha(0xFFFFFF, alpha / 3);

        context.fill(panelX - 1, panelY - 1, panelX + panelW + 1, panelY + panelH + 1, border);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, innerBorder);
        context.fill(panelX + 1, panelY + 1, panelX + panelW - 1, panelY + panelH - 1, bg);

        int headerH = 44;
        int avSize = 32;
        int avX = panelX + 14;
        int avY = panelY + 8;

        context.fill(avX - 1, avY - 1, avX + avSize + 1, avY + avSize + 1, withAlpha(0x8B5CF6, alpha));
        context.fill(avX, avY, avX + avSize, avY + avSize, withAlpha(0x1A1A2E, alpha));

        try {
            context.drawTexture(AVATAR, avX, avY, 0, 0, avSize, avSize, avSize, avSize);
        } catch (Exception ignored) { }

        context.drawTextWithShadow(this.textRenderer, "Fluth Visual", avX + avSize + 12, panelY + 18, withAlpha(0xFFFFFF, alpha));
        context.fill(panelX + 8, panelY + headerH, panelX + panelW - 8, panelY + headerH + 1, withAlpha(0x8B5CF6, alpha));

        int catX = panelX + 8;
        int catY = panelY + headerH + 10;
        int catW = 100;
        int catItemH = 20;

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = catY + i * catItemH;
            boolean selected = (i == selectedCategory);
            boolean hovered = mouseX >= catX && mouseX <= catX + catW && mouseY >= y && mouseY <= y + catItemH - 2;

            if (selected) {
                context.fill(catX, y, catX + catW, y + catItemH - 2, withAlpha(0x8B5CF6, alpha / 2));
                context.fill(catX, y, catX + 2, y + catItemH - 2, withAlpha(0xFFFFFF, alpha));
            } else if (hovered) {
                context.fill(catX, y, catX + catW, y + catItemH - 2, withAlpha(0x8B5CF6, alpha / 5));
            }

            int textColor = selected ? withAlpha(0xFFFFFF, alpha) : withAlpha(0xCCCCCC, alpha);
            context.drawTextWithShadow(this.textRenderer, CATEGORIES[i], catX + 10, y + 4, textColor);
        }

        int modX = panelX + catW + 20;
        int modY = panelY + headerH + 10;
        int modW = panelW - catW - 28;
        int modItemH = 20;

        context.drawTextWithShadow(this.textRenderer, CATEGORIES[selectedCategory], modX, modY, withAlpha(0x8B5CF6, alpha));

        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = modY + 20 + i * modItemH;
            boolean on = enabledModules.contains(module);
            boolean hovered = mouseX >= modX && mouseX <= modX + modW && mouseY >= y && mouseY <= y + modItemH - 2;

            if (hovered) {
                context.fill(modX, y, modX + modW, y + modItemH - 2, withAlpha(0x8B5CF6, alpha / 5));
            }

            int circleColor = on ? withAlpha(0x55FF55, alpha) : withAlpha(0x555555, alpha);
            context.fill(modX + 6, y + 6, modX + 14, y + 14, circleColor);
            context.drawTextWithShadow(this.textRenderer, module, modX + 20, y + 4, withAlpha(0xFFFFFF, alpha));
        }
    }

    private int withAlpha(int rgb, int alpha) {
        if (alpha > 255) alpha = 255;
        if (alpha < 0) alpha = 0;
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int screenW = this.width;
        int screenH = this.height;
        int panelW = 380;
        int panelH = 240;
        int panelX = (screenW - panelW) / 2;
        int panelY = (screenH - panelH) / 2;
        int headerH = 44;

        int catX = panelX + 8;
        int catY = panelY + headerH + 10;
        int catW = 100;
        int catItemH = 20;

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = catY + i * catItemH;
            if (mouseX >= catX && mouseX <= catX + catW && mouseY >= y && mouseY <= y + catItemH - 2) {
                selectedCategory = i;
                return true;
            }
        }

        int modX = panelX + catW + 20;
        int modY = panelY + headerH + 10;
        int modW = panelW - catW - 28;
        int modItemH = 20;

        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = modY + 20 + i * modItemH;
            if (mouseX >= modX && mouseX <= modX + modW && mouseY >= y && mouseY <= y + modItemH - 2) {
                if (enabledModules.contains(module)) {
                    enabledModules.remove(module);
                } else {
                    enabledModules.add(module);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}