package com.fluthvisual.modules;

import net.minecraft.client.MinecraftClient;

public class FullBright extends Module {
    public static FullBright INSTANCE = new FullBright();
    private double oldGamma = -1;

    public FullBright() {
        super("Full Bright");
    }

    @Override
    public void onToggle() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        if (enabled) {
            if (oldGamma == -1) {
                oldGamma = mc.options.getGamma().getValue();
            }
            mc.options.getGamma().setValue(10.0);
        } else {
            if (oldGamma != -1) {
                mc.options.getGamma().setValue(oldGamma);
                oldGamma = -1;
            }
        }
    }
}