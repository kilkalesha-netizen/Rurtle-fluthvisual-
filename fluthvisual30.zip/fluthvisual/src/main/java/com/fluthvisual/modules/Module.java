package com.fluthvisual.modules;

public abstract class Module {
    public String name;
    public boolean enabled = false;

    public Module(String name) {
        this.name = name;
    }

    public void toggle() {
        enabled = !enabled;
        onToggle();
    }

    public void onToggle() {
        // переопределяется в наследниках
    }
}