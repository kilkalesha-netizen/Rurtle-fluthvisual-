package com.fluthvisual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final String[] CATEGORIES = {"Combat", "Visuals", "Player", "World", "World All"};
    private static int selectedCategory = 1;

    private static final String[][] MODULES = {
        { },
        { "Custom Sky", "View Model", "Hand Aura", "Block Overlay", "Aspect Ratio", "Watermark" },
        { },
        { "Full Bright" },
        { }
    };

    private static final List<String> enabledModules = new ArrayList<>();

    private long openTime = -1;
    private static final long ANIM_DURATION = 250L;

    public ClickGui() {
        super(Text.literal("Fluth Visual"));
    }

    private float getAnimationProgress() {
        if (openTime == -1) openTime = System.currentTimeMillis();
        long elapsed = System.currentTimeMillis() - openTime;
        float t = Math.min(1.0f, elapsed / (float) ANIM_DURATION);
        return 1.0f - (1.0f - t) * (1.0f - t);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float anim = getAnimationProgress();
        if (anim <= 0.01f) return;

        int alpha = (int) (anim * 255);
        int screenW = this.width;
        int screenH = this.height;

        int panelW = 380;
        int panelH = 240;
        int panelX = (screenW - panelW) / 2;
        int panelY = (screenH - panelH) / 2;

        // === ГЛАВНАЯ ПАНЕЛЬ (СКРУГЛЁННАЯ) ===
        int bgPanel = withAlpha(0x0A0A12, alpha);
        int borderPanel = withAlpha(0x8B5CF6, alpha);

        // Обводка (рисуем прямоугольник, потом закрашиваем центр фоном)
        drawRoundedRect(context, panelX, panelY, panelX + panelW, panelY + panelH, 8, borderPanel);
        drawRoundedRect(context, panelX + 1, panelY + 1, panelX + panelW - 1, panelY + panelH - 1, 7, bgPanel);

        // === ЗАГОЛОВОК: АВАТАРКА + НАЗВАНИЕ ===
        int headerH = 44;
        int avSize = 32;
        int avX = panelX + 14;
        int avY = panelY + 8;

        drawRoundedRect(context, avX - 1, avY - 1, avX + avSize + 1, avY + avSize + 1, 4, withAlpha(0x8B5CF6, alpha));
        drawRoundedRect(context, avX, avY, avX + avSize, avY + avSize, 3, withAlpha(0x1A1A2E, alpha));

        context.drawTextWithShadow(this.textRenderer, "Fluth Visual", avX + avSize + 12, panelY + 18, withAlpha(0xFFFFFF, alpha));

        // Разделительная линия
        context.fill(panelX + 12, panelY + headerH, panelX + panelW - 12, panelY + headerH + 1, withAlpha(0x8B5CF6, alpha / 2));

        // === ЛЕВАЯ ПАНЕЛЬ — КАТЕГОРИИ (СКРУГЛЁННЫЕ ПОЛОСЫ) ===
        int catX = panelX + 10;
        int catY = panelY + headerH + 10;
        int catW = 100;
        int catItemH = 24;
        int catPad = 3;

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = catY + i * catItemH;
            boolean selected = (i == selectedCategory);
            boolean hovered = mouseX >= catX && mouseX <= catX + catW && mouseY >= y && mouseY <= y + catItemH - catPad;

            int fillCol;
            if (selected) {
                fillCol = withAlpha(0x4A2D7A, alpha);       // насыщенный тёмно-фиолетовый
            } else if (hovered) {
                fillCol = withAlpha(0x2A1F45, alpha);
            } else {
                fillCol = withAlpha(0x14141F, alpha);
            }

            int bordCol = selected ? withAlpha(0xBB86FF, alpha) : withAlpha(0x3A2D5A, alpha);

            // Скруглённая полоса с рамкой
            drawRoundedRect(context, catX, y, catX + catW, y + catItemH - catPad, 5, bordCol);
            drawRoundedRect(context, catX + 1, y + 1, catX + catW - 1, y + catItemH - catPad - 1, 4, fillCol);

            int textColor = selected ? withAlpha(0xFFFFFF, alpha) : withAlpha(0xCCCCCC, alpha);
            context.drawTextWithShadow(this.textRenderer, CATEGORIES[i], catX + 12, y + 6, textColor);
        }

        // === ПРАВАЯ ПАНЕЛЬ — МОДУЛИ (СКРУГЛЁННЫЕ ПОЛОСЫ) ===
        int modX = panelX + catW + 25;
        int modY = panelY + headerH + 10;
        int modW = panelW - catW - 40;
        int modItemH = 24;
        int modPad = 3;

        context.drawTextWithShadow(this.textRenderer, CATEGORIES[selectedCategory], modX + 4, modY, withAlpha(0x8B5CF6, alpha));

        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = modY + 18 + i * modItemH;
            boolean on = enabledModules.contains(module);
            boolean hovered = mouseX >= modX && mouseX <= modX + modW && mouseY >= y && mouseY <= y + modItemH - modPad;

            int fillCol;
            if (on) {
                fillCol = withAlpha(0x2D1B4E, alpha);        // тёмно-фиолетовый, как просили
            } else if (hovered) {
                fillCol = withAlpha(0x1F1F2E, alpha);
            } else {
                fillCol = withAlpha(0x121220, alpha);
            }

            int bordCol;
            if (on) {
                bordCol = withAlpha(0xBB86FF, alpha);
            } else {
                bordCol = withAlpha(0x2A2A3E, alpha);
            }

            drawRoundedRect(context, modX, y, modX + modW, y + modItemH - modPad, 5, bordCol);
            drawRoundedRect(context, modX + 1, y + 1, modX + modW - 1, y + modItemH - modPad - 1, 4, fillCol);

            // Звёзды на включённом модуле
            if (on) {
                drawStars(context, modX + 4, y + 4, modX + modW - 4, y + modItemH - modPad - 4, alpha);
            }

            // Индикатор
            int circleColor = on ? withAlpha(0xBB86FF, alpha) : withAlpha(0x555555, alpha);
            context.fill(modX + 8, y + 8, modX + 14, y + 14, circleColor);

            int textColor = on ? withAlpha(0xFFFFFF, alpha) : withAlpha(0xCCCCCC, alpha);
            context.drawTextWithShadow(this.textRenderer, module, modX + 22, y + 6, textColor);
        }
    }

    // === НАСТОЯЩЕЕ СКРУГЛЕНИЕ ===
    // Рисует прямоугольник со скруглёнными углами, радиусом radius.
    // Каждый угол "отрезается" по 4 пикселя.
    private void drawRoundedRect(DrawContext ctx, int x1, int y1, int x2, int y2, int radius, int color) {
        // Основное тело (без углов)
        ctx.fill(x1 + radius, y1, x2 - radius, y2, color);          // верхняя полоса
        ctx.fill(x1, y1 + radius, x1 + radius, y2 - radius, color);  // левая
        ctx.fill(x2 - radius, y1 + radius, x2, y2 - radius, color);  // правая
        ctx.fill(x1 + radius, y1 + radius, x2 - radius, y2 - radius, color); // центр

        // Углы — маленькие "вырезы"
        // Верхний левый
        ctx.fill(x1 + 1, y1 + 1, x1 + radius, y1 + radius, color);
        // Верхний правый
        ctx.fill(x2 - radius, y1 + 1, x2 - 1, y1 + radius, color);
        // Нижний левый
        ctx.fill(x1 + 1, y2 - radius, x1 + radius, y2 - 1, color);
        // Нижний правый
        ctx.fill(x2 - radius, y2 - radius, x2 - 1, y2 - 1, color);
    }

    // Рисует маленькие "звёзды" на включённом модуле
    private void drawStars(DrawContext ctx, int x1, int y1, int x2, int y2, int alpha) {
        int starColor = withAlpha(0xE0C8FF, alpha / 2);
        // Крестики из 5 пикселей — имитация звёзд
        int[][] stars = {
            {10, 3}, {30, 9}, {50, 4}, {70, 10}, {90, 5},
            {18, 12}, {38, 2}, {58, 12}, {78, 8}, {95, 11}
        };
        for (int[] s : stars) {
            int sx = x1 + s[0];
            int sy = y1 + s[1];
            if (sx + 2 < x2 && sy + 2 < y2) {
                // Плюсик
                ctx.fill(sx, sy + 1, sx + 3, sy + 2, starColor); // горизонталь
                ctx.fill(sx + 1, sy, sx + 2, sy + 3, starColor); // вертикаль
            }
        }
    }

    private int withAlpha(int rgb, int alpha) {
        if (alpha > 255) alpha = 255;
        if (alpha < 0) alpha = 0;
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int screenW = this.width;
        int screenH = this.height;
        int panelW = 380;
        int panelH = 240;
        int panelX = (screenW - panelW) / 2;
        int panelY = (screenH - panelH) / 2;
        int headerH = 44;

        int catX = panelX + 10;
        int catY = panelY + headerH + 10;
        int catW = 100;
        int catItemH = 24;
        int catPad = 3;

        for (int i = 0; i < CATEGORIES.length; i++) {
            int y = catY + i * catItemH;
            if (mouseX >= catX && mouseX <= catX + catW && mouseY >= y && mouseY <= y + catItemH - catPad) {
                selectedCategory = i;
                return true;
            }
        }

        int modX = panelX + catW + 25;
        int modY = panelY + headerH + 10;
        int modW = panelW - catW - 40;
        int modItemH = 24;
        int modPad = 3;

        for (int i = 0; i < MODULES[selectedCategory].length; i++) {
            String module = MODULES[selectedCategory][i];
            int y = modY + 18 + i * modItemH;
            if (mouseX >= modX && mouseX <= modX + modW && mouseY >= y && mouseY <= y + modItemH - modPad) {
                if (enabledModules.contains(module)) {
                    enabledModules.remove(module);
                } else {
                    enabledModules.add(module);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}