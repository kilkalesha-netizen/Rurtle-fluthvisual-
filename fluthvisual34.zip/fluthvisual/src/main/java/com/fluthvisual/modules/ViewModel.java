package com.fluthvisual.modules;

public class ViewModel extends Module {
    public static ViewModel INSTANCE = new ViewModel();

    // Настройки (можно менять через меню в будущем)
    public static float scaleMain = 1.0f;      // размер предмета в правой руке
    public static float scaleOff = 1.0f;       // размер предмета в левой руке
    public static float offsetX = 0.0f;        // сдвиг влево/вправо
    public static float offsetY = 0.0f;        // сдвиг вверх/вниз
    public static float offsetZ = 0.0f;        // сдвиг вперёд/назад

    public ViewModel() {
        super("View Model");
    }
}