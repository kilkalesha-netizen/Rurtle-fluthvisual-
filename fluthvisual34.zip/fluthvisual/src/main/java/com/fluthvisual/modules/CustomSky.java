package com.fluthvisual.modules;

public class CustomSky extends Module {
    public static CustomSky INSTANCE = new CustomSky();

    public CustomSky() {
        super("Custom Sky");
    }
}