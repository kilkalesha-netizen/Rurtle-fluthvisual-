package com.fluthvisual.modules;

public class Optimization extends Module {
    public static Optimization INSTANCE = new Optimization();
    public static double maxEntityDistance = 48.0;

    public Optimization() {
        super("Optimization");
    }

    public static float getMaxEntityDistance() {
        return (float) maxEntityDistance;
    }
}