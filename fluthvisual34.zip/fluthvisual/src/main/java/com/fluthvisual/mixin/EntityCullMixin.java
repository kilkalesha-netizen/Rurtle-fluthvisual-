package com.fluthvisual.mixin;

import com.fluthvisual.modules.Optimization;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityCullMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void onShouldRender(Entity entity, Frustum frustum, double x, double y, double z,
                                CallbackInfoReturnable<Boolean> cir) {
        if (!Optimization.INSTANCE.enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return;

        if (entity == mc.player) return;
        if (entity.hasPassenger(mc.player)) return;

        double distSq = mc.player.squaredDistanceTo(entity);
        double maxDist = Optimization.maxEntityDistance;
        if (distSq > maxDist * maxDist) {
            cir.setReturnValue(false);
        }
    }
}