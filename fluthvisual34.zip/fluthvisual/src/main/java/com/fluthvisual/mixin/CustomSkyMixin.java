package com.fluthvisual.mixin;

import com.fluthvisual.modules.CustomSky;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public class CustomSkyMixin {

    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void onRenderSky(float red, float green, float blue, CallbackInfo ci) {
        if (CustomSky.INSTANCE.enabled) {
            ci.cancel(); // Отменяем рисование ванильного неба
        }
    }
}