package com.fluthvisual.mixin;

import com.fluthvisual.modules.ViewModel;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class ViewModelMixin {

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void onRenderItem(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                              float swingProgress, ItemStack item, float equipProgress,
                              MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                              CallbackInfo ci) {
        if (!ViewModel.INSTANCE.enabled) return;

        // Определяем, какая рука
        boolean isMainHand = (hand == Hand.MAIN_HAND);

        // Выбираем настройки для конкретной руки
        float scale = isMainHand ? ViewModel.scaleMain : ViewModel.scaleOff;

        // Применяем трансформации к матрице
        // Сначала смещаем, потом масштабируем
        matrices.translate(ViewModel.offsetX, ViewModel.offsetY, ViewModel.offsetZ);
        matrices.scale(scale, scale, scale);
    }
}