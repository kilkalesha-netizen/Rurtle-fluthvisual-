package com.fluthvisual.modules;

public class ViewModel extends Module {
    public static ViewModel INSTANCE = new ViewModel();

    // Настройки (значения по умолчанию)
    public static float scaleMain = 1.0f;      // Размер предмета в правой руке
    public static float scaleOff = 1.0f;       // Размер предмета в левой руке
    public static float offsetX = 0.0f;        // Сдвиг влево/вправо
    public static float offsetY = 0.0f;        // Сдвиг вверх/вниз
    public static float offsetZ = 0.0f;        // Сдвиг вперёд/назад

    public ViewModel() {
        super("View Model");
    }
}