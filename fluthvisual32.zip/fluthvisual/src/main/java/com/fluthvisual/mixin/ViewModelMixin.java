package com.fluthvisual.mixin;

import com.fluthvisual.modules.ViewModel;
import net.minecraft.client.render.item.HeldItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class ViewModelMixin {

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void onRenderItem(CallbackInfo ci) {
        if (!ViewModel.INSTANCE.enabled) return;

        // Здесь нужно будет вставить изменение матриц трансформации.
        // Точная сигнатура метода в 1.21.4 пока неизвестна —
        // код упадёт, и мы посмотрим лог, чтобы дописать.
    }
}